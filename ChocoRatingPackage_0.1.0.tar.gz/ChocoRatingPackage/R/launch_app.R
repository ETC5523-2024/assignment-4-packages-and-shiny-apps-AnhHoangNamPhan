#' Launch the Chocolate Rating Shiny App
#'
#' This function launches a Shiny app that displays chocolate rating data.
#' @export
launch_app <- function() {
  appDir <- system.file("shiny-app", package = "ChocoRatingPackage")
  if (appDir == "") {
    stop("Could not find app directory. Try re-installing `ChocoRatingPackage`.", call. = FALSE)
  }
  shiny::runApp(appDir, display.mode = "normal")
}

